</main>
    <footer>
        <p>&copy; <?= date('Y') ?> St Alphonsus Primary School</p>
    </footer>
    <script src="../js/main.js"></script>
</body>
</html>